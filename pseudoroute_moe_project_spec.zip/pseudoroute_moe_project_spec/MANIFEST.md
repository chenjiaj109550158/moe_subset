# Specification Manifest

Generated: 2026-07-26T20:10:41.748168+00:00

## Files

| File | Bytes | SHA-256 | Purpose |
|---|---:|---|---|
| `README.md` | 5,219 | `5f0d9fd660dcbd44dc0db2a1d9a048eb76e36c706ad004c71e0cf2d2b1ddd259` | English index and project summary |
| `README_zh-TW.md` | 2,638 | `a06486954cd40e1dcd620c741e39900a2ccdb690e50ee947bbbb7f0a2a3f2e98` | Traditional Chinese overview |
| `00_CODEX_START_HERE.md` | 8,884 | `c17272f628a11c8f89bf79f3219183d1727244305f0884232e6bdc3051bb006e` | Master instructions for Codex |
| `01_RESEARCH_SPEC.md` | 12,769 | `4356a30c5c1d8a106bf8a36e4a950ee35932042944b4f58cdc6d158acb75363a` | Research problem, hypotheses, and gates |
| `02_RELATED_WORK_AND_NOVELTY.md` | 13,078 | `4e9f9642d463cf4e72b5e808c131ac98410c40b44f3a660d5ca5b87fc0660fcc` | Prior work and claim boundaries |
| `03_SYSTEM_ARCHITECTURE.md` | 19,955 | `3b40d0d193a076a706198464fa197ef5459ce33465fb9cf8339ea8b665cacb76` | Repository and module architecture |
| `04_ALGORITHMS.md` | 20,779 | `f069a217684031fa229d088c8ed1333aaff4f5a8dfde77dc6df9548726a07dfe` | Mathematical definitions and pseudocode |
| `05_EXPERIMENT_PLAN.md` | 15,700 | `78aa50e3c5b89440a379bfe8be14251971314279a956261f4d2ee112cd7030b1` | Phased experiment design and metrics |
| `06_IMPLEMENTATION_ROADMAP.md` | 9,562 | `af8dc40268c4d66dfdc48b8d3838c96f44ca9befc76185e659df2f2ea92e36bd` | Milestones, deliverables, and tests |
| `07_CONFIG_AND_DATA_SCHEMAS.md` | 11,898 | `9005e74e519e1f63e1282a12877338ed67b4605e86ae4dd42b466718be0c20e8` | YAML and artifact schemas |
| `08_CODEX_TASK_PROMPTS.md` | 8,945 | `7891dd18fb99ed6394c5f1602b5fdd68df17538dcb7c981fea745f00bbabe0c9` | Incremental copy-paste Codex prompts |
| `09_RISKS_AND_DECISION_LOG.md` | 9,775 | `17ff760c5f4cd62a7442c9f3b44eaa92ac9a6fa536b3cc49e268aa3aefb2b33b` | Blind spots, mitigations, and pivots |
| `10_REPRODUCIBILITY_CHECKLIST.md` | 7,671 | `827abb80fe089b6cf7c72f0007615fba36345b953bd120a8b5faae981e55d6ef` | Experiment and release checklist |
| `PROJECT_SPEC_ALL_IN_ONE.md` | 148,722 | `f4b85c4cd5398779257294b107593898e2695b5cfb7075225346670cb7f62b69` | Concatenated single-file specification |
